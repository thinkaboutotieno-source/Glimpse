/* ==========================================================
   Glimpse server
   Serves the front end, stores uploads on disk and keeps posts
   in a JSON file. Good for a small community wall; for heavy
   traffic, swap the JSON file for a database and the uploads
   folder for object storage (S3, R2, Cloudinary...).

   Run:  npm install  &&  npm start   →  http://localhost:3000
   ========================================================== */
const express = require("express");
const multer = require("multer");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const { execFile } = require("child_process");

const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, "data");
const UPLOAD_DIR = path.join(ROOT, "uploads");
const DB_FILE = path.join(DATA_DIR, "posts.json");

const MAX_VIDEO_SECONDS = 30;
const MAX_VIDEO_BYTES = 60 * 1e6;
const MAX_PHOTO_BYTES = 12 * 1e6;     // photos arrive already resized by the browser
const MAX_THUMB_BYTES = 2 * 1e6;
const QUOTE_MAX = 280;
const QUOTE_STYLES = ["ink", "paper", "sun", "bloom"];
const THOUGHT_MAX = 500;
const THOUGHT_TINTS = ["cream", "mint", "sky", "blush"];
const REACTIONS = ["love", "hug", "haha", "wow", "sad", "relate"];
const POSTS_PER_10_MIN = 30;          // per IP address
const REACTIONS_PER_10_MIN = 300;     // per IP address

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

/* ----- Tiny JSON "database" ----- */
const SEED = [
  ["We suffer more often in imagination than in reality.", "Seneca", "ink"],
  ["If you want to go fast, go alone. If you want to go far, go together.", "African proverb", "sun"],
  ["Do what you can, with what you have, where you are.", "Theodore Roosevelt", "paper"],
  ["Go confidently in the direction of your dreams.", "Henry David Thoreau", "bloom"],
  ["Nothing great was ever achieved without enthusiasm.", "Ralph Waldo Emerson", "sun"],
  ["Waste no more time arguing what a good person should be. Be one.", "Marcus Aurelius", "ink"],
  ["Little by little, one travels far.", "Proverb", "bloom"],
  ["Until the lion learns to write, tales of the hunt will glorify the hunter.", "African proverb", "paper"],
  ["The best way out is always through.", "Robert Frost", "ink"],
  ["Rest is not idleness.", "John Lubbock", "paper"],
  ["Simplicity is the ultimate sophistication.", "Attributed to Leonardo da Vinci", "sun"],
  ["Wherever you go, go with all your heart.", "Confucius", "bloom"],
];

const SEED_THOUGHTS = [
  ["Moved to a new city three months ago. Today the guy at the coffee stand knew my order. Small thing, felt huge.", "Wanjiru", "mint", { love: 9, hug: 4, relate: 6 }],
  ["Does anyone else rehearse conversations in the shower that never end up happening?", "Anonymous", "cream", { haha: 14, relate: 21 }],
  ["Finished my first 10K this morning. A year ago I couldn't run to the bus stop.", "Otieno", "sky", { love: 12, wow: 5 }],
  ["Missing my grandmother's cooking today. Trying her recipe tonight and I'll probably get it wrong.", "Anonymous", "blush", { hug: 11, sad: 3, love: 7 }],
];
const seedThoughts = now => SEED_THOUGHTS.map(([text, author, tint, reactions], i) => ({
  id: "sample-thought-" + i, type: "thought", author, text, tint, reactions, likes: 0, createdAt: now - [0.15, 1.6, 4, 11][i] * 864e5,
}));

function load() {
  try {
    return JSON.parse(fs.readFileSync(DB_FILE, "utf8"));
  } catch (_) {
    const now = Date.now();
    const posts = SEED.map(([text, quoteBy, style], i) => ({
      id: "sample-" + i, type: "quote", author: "Glimpse", text, quoteBy, style,
      likes: 3 + ((i * 7) % 20), createdAt: now - (i + 1) * 2.4 * 864e5,
    })).concat(seedThoughts(now));
    save(posts);
    return posts;
  }
}
function save(list = posts) {
  const tmp = DB_FILE + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(list, null, 2));
  fs.renameSync(tmp, DB_FILE);               // atomic replace
}
let posts = load();
// Walls created before thoughts existed get the sample thoughts once
const THOUGHTS_MARKER = path.join(DATA_DIR, ".thoughts-seeded");
if (!fs.existsSync(THOUGHTS_MARKER)) {
  if (!posts.some(p => p.type === "thought")) { posts.push(...seedThoughts(Date.now())); save(); }
  fs.writeFileSync(THOUGHTS_MARKER, "1");
}

// Time capsules stay sealed: until they open, nobody gets their contents (not even the poster)
const publicPost = ({ tokenHash, ip, ...p }) => {
  if (p.opensAt && p.opensAt > Date.now()) {
    return { id: p.id, type: p.type, author: p.author, createdAt: p.createdAt, opensAt: p.opensAt, sealed: true, likes: p.likes || 0, width: p.width, height: p.height };
  }
  return p;
};
const isSealed = p => p.opensAt && p.opensAt > Date.now();
const MAX_CAPSULE_YEARS = 10;
const sha256 = s => crypto.createHash("sha256").update(s).digest("hex");
// Like clean(), but keeps line breaks (for thoughts)
const cleanText = (v, max) => String(v ?? "").replace(/\r\n?/g, "\n").replace(/[\u0000-\u0009\u000b-\u001f\u007f]/g, " ")
  .replace(/\n{3,}/g, "\n\n").trim().slice(0, max);
const clean = (v, max) => String(v ?? "").replace(/[\u0000-\u001f\u007f]/g, " ").trim().slice(0, max);
const httpError = (status, message) => Object.assign(new Error(message), { status });

/* ----- Uploads ----- */
const EXT = {
  "image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp",
  "video/mp4": ".mp4", "video/x-m4v": ".mp4", "video/webm": ".webm", "video/quicktime": ".mov",
  "video/3gpp": ".3gp", "video/x-matroska": ".mkv",
};
const EXT_BY_NAME = { mp4: ".mp4", m4v: ".mp4", mov: ".mov", webm: ".webm", "3gp": ".3gp", mkv: ".mkv", jpg: ".jpg", jpeg: ".jpg", png: ".png", webp: ".webp" };
// Use the browser's type, or the file name when the type is missing/generic
function extFor(file) {
  if (EXT[file.mimetype]) return EXT[file.mimetype];
  const ext = (file.originalname.split(".").pop() || "").toLowerCase();
  return EXT_BY_NAME[ext] || null;
}
const isVideoFile = file => file.mimetype.startsWith("video/") || /\.(mp4|m4v|mov|webm|3gp|mkv)$/i.test(file.originalname);
const upload = multer({
  storage: multer.diskStorage({
    destination: UPLOAD_DIR,
    filename: (req, file, cb) => cb(null, crypto.randomUUID() + (extFor(file) || "")),
  }),
  limits: { fileSize: MAX_VIDEO_BYTES, files: 2, fields: 20 },
  fileFilter: (req, file, cb) => {
    const okMedia = file.fieldname === "media" && extFor(file);
    const okThumb = file.fieldname === "thumb" && file.mimetype === "image/jpeg";
    if (okMedia || okThumb) return cb(null, true);
    console.warn(`Rejected upload: field=${file.fieldname} type=${file.mimetype} name=${file.originalname}`);
    cb(httpError(400, "That file type isn't supported. Use JPG, PNG, WebP, MP4, MOV or WebM."));
  },
});

// Reads the real video length with ffprobe when it's installed.
function probeDuration(file) {
  return new Promise(resolve => {
    execFile("ffprobe", ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file], { timeout: 15000 }, (err, out) => {
      const d = parseFloat(out);
      resolve(err || !isFinite(d) ? null : d);
    });
  });
}
let hasFfprobe = false;
execFile("ffprobe", ["-version"], err => {
  hasFfprobe = !err;
  if (!hasFfprobe) console.warn("ffprobe not found: video length is checked in the browser only. Install ffmpeg to check it on the server too.");
});

/* ----- Simple per-IP rate limit for new posts ----- */
function makeLimiter(max, message) {
  const hits = new Map();
  return (req, res, next) => {
    const now = Date.now(), win = 10 * 60 * 1000;
    const list = (hits.get(req.ip) || []).filter(t => now - t < win);
    if (list.length >= max) return res.status(429).json({ error: message });
    list.push(now); hits.set(req.ip, list);
    next();
  };
}
const rateLimit = makeLimiter(POSTS_PER_10_MIN, "You're posting very fast. Wait a few minutes and try again.");
const reactLimit = makeLimiter(REACTIONS_PER_10_MIN, "That's a lot of reactions. Wait a few minutes and try again.");

/* ----- App ----- */
const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(ROOT, "public")));
app.use("/uploads", express.static(UPLOAD_DIR, { maxAge: "7d", immutable: true }));

app.get("/api/posts", (req, res) => {
  res.json(posts.map(publicPost));
});

app.post("/api/posts", rateLimit, upload.fields([{ name: "media", maxCount: 1 }, { name: "thumb", maxCount: 1 }]), async (req, res, next) => {
  const media = req.files?.media?.[0];
  const thumb = req.files?.thumb?.[0];
  const cleanup = () => [media, thumb].forEach(f => f && fs.unlink(f.path, () => {}));

  try {
    const b = req.body;
    const type = b.type;
    if (!["photo", "video", "quote", "thought"].includes(type)) throw httpError(400, "Choose a photo, video, quote or thought to post.");

    const post = {
      id: crypto.randomUUID(),
      type,
      author: clean(b.author, 40) || "Anonymous",
      likes: 0,
      createdAt: Date.now(),
    };

    if (type === "thought") {
      if (media || thumb) throw httpError(400, "Thoughts can't include files.");
      post.text = cleanText(b.text, THOUGHT_MAX);
      if (post.text.length < 2) throw httpError(400, "Write your thought before posting.");
      post.tint = THOUGHT_TINTS.includes(b.tint) ? b.tint : "cream";
      post.reactions = {};
    } else if (type === "quote") {
      if (media || thumb) throw httpError(400, "Quotes can't include files.");
      post.text = clean(b.text, QUOTE_MAX);
      if (post.text.length < 2) throw httpError(400, "Write a quote before posting.");
      post.quoteBy = clean(b.quoteBy, 60);
      post.style = QUOTE_STYLES.includes(b.style) ? b.style : "ink";
    } else {
      if (!media || !thumb) throw httpError(400, "The upload was incomplete. Choose the file again.");
      const isVideo = isVideoFile(media);
      if (isVideo !== (type === "video")) throw httpError(400, `That file doesn't look like a ${type}.`);
      if (!isVideo && media.size > MAX_PHOTO_BYTES) throw httpError(413, "That photo is too large.");
      if (thumb.size > MAX_THUMB_BYTES) throw httpError(413, "The preview image is too large.");

      post.caption = clean(b.caption, 140);
      post.width = Math.round(clamp(Number(b.width) || 0, 0, 10000));
      post.height = Math.round(clamp(Number(b.height) || 0, 0, 10000));
      post.url = "/uploads/" + media.filename;
      post.thumb = "/uploads/" + thumb.filename;

      if (isVideo) {
        const probed = hasFfprobe ? await probeDuration(media.path) : null;
        const duration = probed ?? Number(b.duration);
        if (!(duration > 0)) throw httpError(400, "Couldn't read the length of that video. Try an MP4 file.");
        if (duration > MAX_VIDEO_SECONDS + 0.5) {
          throw httpError(400, `This video is ${Math.round(duration)} seconds long. Videos can be ${MAX_VIDEO_SECONDS} seconds at most.`);
        }
        post.duration = Math.round(duration * 100) / 100;
      }
    }

    if (b.opensAt) {
      const opensAt = Number(b.opensAt);
      if (!(opensAt > Date.now() + 30 * 1000)) throw httpError(400, "Pick an opening time in the future for your time capsule.");
      if (opensAt > Date.now() + MAX_CAPSULE_YEARS * 365.25 * 864e5) throw httpError(400, `Time capsules can stay sealed for up to ${MAX_CAPSULE_YEARS} years.`);
      post.opensAt = Math.round(opensAt);
    }

    const token = crypto.randomBytes(18).toString("hex");
    post.tokenHash = sha256(token);
    posts.unshift(post);
    save();
    res.status(201).json({ post: publicPost(post), deleteToken: token });
  } catch (err) {
    cleanup();
    console.warn("Post rejected:", err.message);
    next(err);
  }
});

app.post("/api/posts/:id/like", (req, res) => {
  const p = posts.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "That post no longer exists." });
  if (isSealed(p)) return res.status(403).json({ error: "This time capsule is still sealed." });
  const delta = req.body?.delta === -1 ? -1 : 1;
  p.likes = Math.max(0, (p.likes || 0) + delta);
  save();
  res.json({ likes: p.likes });
});

// One reaction per person per thought: the browser sends what it adds and what it removes
app.post("/api/posts/:id/react", reactLimit, (req, res) => {
  const p = posts.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "That post no longer exists." });
  if (p.type !== "thought") return res.status(400).json({ error: "Only thoughts take reactions." });
  if (isSealed(p)) return res.status(403).json({ error: "This time capsule is still sealed." });
  const { add, remove } = req.body || {};
  p.reactions = p.reactions || {};
  if (REACTIONS.includes(remove)) p.reactions[remove] = Math.max(0, (p.reactions[remove] || 0) - 1);
  if (REACTIONS.includes(add)) p.reactions[add] = (p.reactions[add] || 0) + 1;
  save();
  res.json({ reactions: p.reactions });
});

app.delete("/api/posts/:id", (req, res) => {
  const p = posts.find(x => x.id === req.params.id);
  if (!p) return res.status(404).json({ error: "That post no longer exists." });
  const token = req.get("X-Delete-Token") || "";
  const adminOk = process.env.ADMIN_TOKEN && token === process.env.ADMIN_TOKEN;
  if (!adminOk && (!p.tokenHash || sha256(token) !== p.tokenHash)) {
    return res.status(403).json({ error: "Only the person who posted this can delete it." });
  }
  posts = posts.filter(x => x !== p);
  save();
  for (const u of [p.url, p.thumb]) if (u) fs.unlink(path.join(UPLOAD_DIR, path.basename(u)), () => {});
  res.status(204).end();
});

// Errors (including multer's file-size errors) come back as friendly JSON
app.use((err, req, res, next) => {
  if (err instanceof multer.MulterError) {
    const msg = err.code === "LIMIT_FILE_SIZE"
      ? `That file is too large. Videos can be up to ${MAX_VIDEO_BYTES / 1e6} MB.`
      : "The upload couldn't be read. Try again.";
    return res.status(413).json({ error: msg });
  }
  if (err.status) return res.status(err.status).json({ error: err.message });
  console.error(err);
  res.status(500).json({ error: "Something went wrong on the server. Try again." });
});

function clamp(n, a, b) { return Math.min(b, Math.max(a, n)); }

app.listen(PORT, () => console.log(`Glimpse is running at http://localhost:${PORT}`));
